#!/bin/sh -
#PBS -q lx_edu
#PBS -l elapstim_req=0:10:00

cd $PBS_O_WORKDIR

for threads in 1 2 4 8 16 32; do
    echo "OMP_NUM_THREADS=${threads}"
    export OMP_NUM_THREADS=${threads}
    time ./n-body
done
