#include <stdlib.h>
#include <stdio.h>
#include <math.h>
#include <time.h>
#include <omp.h>

typedef struct {
    double x, y, z;
} vector;

#define NUM_BODIES 10000
#define TIME_STEP 10
#define GRAV_CONST 0.01

double *masses;
vector *positions, *velocities, *accelerations;

vector addVectors(vector a, vector b) {
    vector c = {a.x + b.x, a.y + b.y, a.z + b.z};
    return c;
}

vector scaleVector(double b, vector a) {
    vector c = {b * a.x, b * a.y, b * a.z};
    return c;
}

vector subtractVectors(vector a, vector b) {
    vector c = {a.x - b.x, a.y - b.y, a.z - b.z};
    return c;
}

double mod(vector a) {
    return sqrt(a.x * a.x + a.y * a.y + a.z * a.z);
}

double random_number(double max, double min) {
    double x = (double)rand() / RAND_MAX;
    return (max - min) * x + min;
}

void initiateSystem(void) {
    masses = (double *)malloc(NUM_BODIES * sizeof(double));
    positions = (vector *)malloc(NUM_BODIES * sizeof(vector));
    velocities = (vector *)malloc(NUM_BODIES * sizeof(vector));
    accelerations = (vector *)malloc(NUM_BODIES * sizeof(vector));

    if (!masses || !positions || !velocities || !accelerations) {
        fprintf(stderr, "Memory allocation failed!\n");
        exit(EXIT_FAILURE);
    }

    for (int i = 0; i < NUM_BODIES; i++) {
        masses[i] = random_number(0, 1);
        positions[i].x = random_number(-1, 1);
        positions[i].y = random_number(-1, 1);
        positions[i].z = random_number(-1, 1);
        velocities[i].x = random_number(-1, 1);
        velocities[i].y = random_number(-1, 1);
        velocities[i].z = random_number(-1, 1);
    }
}


void computeAccelerations() {
    int i, j;

    #pragma omp parallel for schedule(dynamic) shared(positions, masses, accelerations) private(i, j)
    for (i = 0; i < NUM_BODIES; i++) {
        accelerations[i].x = accelerations[i].y = accelerations[i].z = 0;
        for (j = 0; j < NUM_BODIES; j++) {
            if (i != j) {
                vector diff = subtractVectors(positions[j], positions[i]);
                double dist_cubed = pow(mod(diff), 3);
                vector acc = scaleVector(GRAV_CONST * masses[j] / dist_cubed, diff);
                accelerations[i] = addVectors(accelerations[i], acc);
            }
        }
    }
}



void computeVelocities() {
    #pragma omp parallel for
    for (int i = 0; i < NUM_BODIES; i++) {
        velocities[i] = addVectors(velocities[i], accelerations[i]);
    }
}

void computePositions() {
    #pragma omp parallel for
    for (int i = 0; i < NUM_BODIES; i++) {
        positions[i] = addVectors(positions[i], addVectors(velocities[i], scaleVector(0.5, accelerations[i])));
    }
}

void resolveCollisions() {
    #pragma omp parallel for
    for (int idx = 0; idx < (NUM_BODIES * (NUM_BODIES - 1)) / 2; idx++) {
        int i = idx / (NUM_BODIES - 1);
        int j = idx % (NUM_BODIES - 1) + 1 + i;

        if (j >= NUM_BODIES) continue;

        if (positions[i].x == positions[j].x &&
            positions[i].y == positions[j].y &&
            positions[i].z == positions[j].z) {
            vector temp = velocities[i];
            velocities[i] = velocities[j];
            velocities[j] = temp;
        }
    }
}


void simulate() {
    computeAccelerations();
    computePositions();
    computeVelocities();
    resolveCollisions();
}

void timer_start(struct timespec *t) {
    clock_gettime(CLOCK_REALTIME, t);
}

void timer_stop(struct timespec *b, struct timespec *e) {
    clock_gettime(CLOCK_REALTIME, e);
    double elapsed = (e->tv_sec - b->tv_sec) + (e->tv_nsec - b->tv_nsec) / 1e9;
    printf("%f [sec]\n", elapsed);
}

int main(int argc, char **argv) {
    int i;
    struct timespec bgn, end;

    srand(time(NULL));
    initiateSystem();

    for (i = 0; i < TIME_STEP; i++) {
        printf("\nCycle %d:\n", i + 1);
        timer_start(&bgn);
        simulate();
        timer_stop(&bgn, &end);
    }

    free(masses);
    free(positions);
    free(velocities);
    free(accelerations);

    return 0;
}

