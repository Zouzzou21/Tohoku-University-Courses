#include <stdio.h>

int main()
{
    /**** variable declaration ****/
    
    
    /**** processing contents ****/
    
    
    
    return 0;
    
}
