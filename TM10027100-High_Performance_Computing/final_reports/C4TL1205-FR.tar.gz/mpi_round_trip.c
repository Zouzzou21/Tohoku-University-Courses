#include <mpi.h>
#include <stdio.h>
#include <stdlib.h>
#include <time.h>

void measure_latency_bandwidth(int data_size) {
    int rank;
    MPI_Comm_rank(MPI_COMM_WORLD, &rank);

    char *data = (char *)malloc(data_size);
    for (int i = 0; i < data_size; i++) {
        data[i] = 'a'; // Fill with dummy data
    }

    MPI_Barrier(MPI_COMM_WORLD); // Synchronize processes

    struct timespec start, end;
    if (rank == 0) {
        // Node 0: Send and receive data
        clock_gettime(CLOCK_MONOTONIC, &start);
        MPI_Send(data, data_size, MPI_CHAR, 1, 0, MPI_COMM_WORLD);
        MPI_Recv(data, data_size, MPI_CHAR, 1, 0, MPI_COMM_WORLD, MPI_STATUS_IGNORE);
        clock_gettime(CLOCK_MONOTONIC, &end);
    } else if (rank == 1) {
        // Node 1: Receive and send data
        MPI_Recv(data, data_size, MPI_CHAR, 0, 0, MPI_COMM_WORLD, MPI_STATUS_IGNORE);
        MPI_Send(data, data_size, MPI_CHAR, 0, 0, MPI_COMM_WORLD);
    }

    if (rank == 0) {
        double elapsed_time = (end.tv_sec - start.tv_sec) + (end.tv_nsec - start.tv_nsec) / 1e9;
        double bandwidth = (2.0 * data_size) / (elapsed_time * 1e6); // Bandwidth in MB/s
        double latency = (elapsed_time / 2.0) * 1e6; // Latency in microseconds

        printf("Data size: %d bytes, Time: %.6f seconds, Latency: %.2f microseconds, Bandwidth: %.2f MB/s\n",
               data_size, elapsed_time, latency, bandwidth);
    }

    free(data);
}

int main(int argc, char **argv) {
    MPI_Init(&argc, &argv);

    int rank, size;
    MPI_Comm_rank(MPI_COMM_WORLD, &rank);
    MPI_Comm_size(MPI_COMM_WORLD, &size);

    if (size < 2) {
        if (rank == 0) {
            fprintf(stderr, "Error: This program requires at least 2 processes.\n");
        }
        MPI_Finalize();
        return 1;
    }

    // Measure for varying data sizes
    for (int data_size = 1; data_size <= 1024 * 1024; data_size *= 2) {
        measure_latency_bandwidth(data_size);
    }

    MPI_Finalize();
    return 0;
}
