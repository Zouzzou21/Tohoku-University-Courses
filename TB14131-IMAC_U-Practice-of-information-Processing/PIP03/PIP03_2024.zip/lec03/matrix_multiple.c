/*
 matrix_multiple.c
 */

#include <stdio.h>

int main()
{
    
    /**** (1) variable declaration ****/
    int A[4][3] = {{1,2,3},{4,5,6},{1,2,3},{4,5,6}};
    int B[3][4] = {{1,2,3,4},{5,6,7,8},{1,2,3,4}};
    int C[4][4] = {{}};
    
    
    /**** (2) processing contents ****/
    
    /* A*B */
    
    
    /* Display results */

    
    return 0;
    
}



