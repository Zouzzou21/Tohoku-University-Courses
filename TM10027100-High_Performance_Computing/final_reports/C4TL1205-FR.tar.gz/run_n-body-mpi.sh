#!/bin/sh -
#PBS -q lx_edu
#PBS -l elapstim_req=0:10:00

cd $PBS_O_WORKDIR

for processes in 1 2 4 8 16 32; do
    echo "mpirun -np ${processes} ./n-body-mpi"
    time mpirun -np ${processes} ./n-body-mpi
done