#!/bin/sh -
#PBS -q lx_edu
#PBS -l elapstim_req=0:10:00

# Ensure we're in the right directory
cd "${PBS_O_WORKDIR}"

time ./n-body-serial
